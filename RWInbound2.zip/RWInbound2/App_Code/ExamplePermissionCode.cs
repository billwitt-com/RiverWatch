﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text; 


namespace RWInbound2.Data
{
    public class ExamplePermissionCode
    {
        public static void permissionExample()
        {
            //bool allowed = false; 
            //// public static bool Test(string pageName, string controlName)

            //allowed = App_Code.Permissions.Test(Page.ToString(), "PAGE");
            //if (!allowed)
            //    Response.Redirect("~/index.aspx"); 
        }
          
    }
}