﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RWInbound2.Admin
{
	public partial class AdminOrgStatus : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

    }
}